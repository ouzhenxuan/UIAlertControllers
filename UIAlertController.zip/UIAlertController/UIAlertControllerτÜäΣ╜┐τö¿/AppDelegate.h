//
//  AppDelegate.h
//  UIAlertController的使用
//
//  Created by ozx on 15/6/18.
//  Copyright (c) 2015年 ozx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

