//
//  ViewController.m
//  UIAlertController的使用
//
//  Created by ozx on 15/6/18.
//  Copyright (c) 2015年 ozx. All rights reserved.
//

#import "ViewController.h"
#define IOS8 [[[UIDevice currentDevice]systemVersion] floatValue] >= 8.0
#define wSrceem [UIScreen mainScreen].bounds.size.width
#define hSrceem [UIScreen mainScreen].bounds.size.height

@interface ViewController ()<UIActionSheetDelegate>
{
    UIDatePicker * datePicker7;
    UIAlertView *customAlertView;
    UIView * cover;
}
- (IBAction)alertview:(id)sender;
- (IBAction)actionsheet:(id)sender;
- (IBAction)diyAlertView:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UINavigationBar *nav = [[UINavigationBar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    //创建navbaritem
    UINavigationItem *NavTitle = [[UINavigationItem alloc] initWithTitle:@"详细介绍"];
    
    [nav pushNavigationItem:NavTitle animated:YES];
    [self.navigationController.navigationBar pushNavigationItem:NavTitle animated:NO];
    
    cover = [[UIView alloc]initWithFrame:CGRectMake(0, hSrceem, wSrceem, hSrceem)];
    cover.backgroundColor = [UIColor clearColor];
//    cover.hidden = YES;
    UIView * bgcover = [[UIView alloc] initWithFrame:CGRectMake(0, 0, wSrceem, hSrceem)];
    [cover addSubview:bgcover];
    bgcover.backgroundColor = [UIColor blackColor];
    bgcover.alpha = 0.2;
    
    UIButton * btn = [UIButton buttonWithType:UIButtonTypeContactAdd];
    btn.frame = CGRectMake(100, 100, 100, 100);
    [cover addSubview:btn];
    [btn addTarget:self action:@selector(hiddenTheCover) forControlEvents:UIControlEventTouchDown];

    
    [[UIApplication sharedApplication].keyWindow addSubview:cover];
//    [self.view addSubview:nav];
//    self.navigationController.title = @"123";
}

-(void)hiddenTheCover{
    [UIView animateWithDuration:0.25 animations:^{
        cover.frame = CGRectMake(0, hSrceem, wSrceem, hSrceem);
    } completion:^(BOOL finished) {
        cover.hidden = YES;
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)alertview:(id)sender {
    if (IOS8) {
        UIDatePicker *datePicker = [[UIDatePicker alloc] init];
        datePicker.datePickerMode = UIDatePickerModeDate;
        
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        
        [alert.view addSubview:datePicker];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
            
            //实例化一个NSDateFormatter对象
            [dateFormat setDateFormat:@"yyyy-MM-dd"];//设定时间格式
            
            NSString *dateString = [dateFormat stringFromDate:datePicker.date];
            
            //求出当天的时间字符串
            NSLog(@"%@",dateString);
            
            
        }];
        
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
        }];
        
        [alert addAction:ok];
        
        [alert addAction:cancel];
        
        [self presentViewController:alert animated:YES completion:^{ }];
    }else{
        UIDatePicker *datePicker = [[UIDatePicker alloc] init];
        datePicker.datePickerMode = UIDatePickerModeDate;
        //[datePicker addTarget:self action:@selector(timeChange:) forControlEvents:UIControlEventValueChanged];
        datePicker7 = datePicker;
        
        UIActionSheet* startsheet = [[UIActionSheet alloc] initWithTitle:@"\n\n\n\n\n\n\n\n\n\n\n\n"
                                                                delegate:self
                                                       cancelButtonTitle:nil
                                                  destructiveButtonTitle:nil
                                                       otherButtonTitles:@"确定",
                                     @"取消", nil];
        startsheet.tag = 333;
        [startsheet addSubview:datePicker];
        [startsheet showInView:self.view];
    }

}

- (IBAction)actionsheet:(id)sender {
    if(IOS8){
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"什么鬼" message:@"\n\n" preferredStyle:UIAlertControllerStyleAlert];
        
        UITextField * text = [[UITextField alloc] initWithFrame:CGRectMake(15, 64, 240, 30)];//wight = 270;
        text.borderStyle = UITextBorderStyleRoundedRect;//设置边框的样式
        [alert.view addSubview:text];
        
        UIAlertAction *ok = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
            NSLog(@"%@",text.text);
            
            
        }];
        
        UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            
        }];
        
        [alert addAction:ok];
        
        [alert addAction:cancel];
        
        [self presentViewController:alert animated:YES completion:^{ }];
    }else{
        
        if (customAlertView==nil) {
            customAlertView = [[UIAlertView alloc] initWithTitle:@"自定义服务器地址" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        }
        [customAlertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
        
        UITextField *nameField = [customAlertView textFieldAtIndex:0];
        nameField.placeholder = @"请输入一个名称";
        
        [customAlertView show];
    }
}

- (IBAction)diyAlertView:(id)sender {
//    float a = wSrceem;
    cover.hidden = NO;
    [UIView animateWithDuration:0.25 animations:^{
        cover.frame = CGRectMake(0, 0, wSrceem, hSrceem);
    }];
    
}




- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (actionSheet.tag) {
        
            
        case 333://设置出生日期
        {
            if (buttonIndex == 0)//确定
            {
                NSLog(@"0");
                NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
                
                //实例化一个NSDateFormatter对象
                
                [dateFormat setDateFormat:@"yyyy-MM-dd"];//设定时间格式
                
                NSString *dateString = [dateFormat stringFromDate:datePicker7.date];
                
                //求出当天的时间字符串
                NSLog(@"%@",dateString);
                
            }
        }
            break;
        default://退出登录
        {
        }
            break;
    }
    actionSheet.delegate=nil;
}






@end
